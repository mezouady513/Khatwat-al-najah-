function changeLanguage() {
  alert("تم تغيير اللغة!"); // هذه يمكن استبدالها بكود لتغيير النصوص أو الترجمة
}// تغيير اللغة عند الضغط على الزر
function changeLanguage() {
  // هنا يمكن تغيير النصوص باستخدام JavaScript عند التبديل بين اللغات.
  // على سبيل المثال: استبدال النصوص باللغة الإنجليزية عند الضغط
  alert("تم تغيير اللغة!"); // هذه مجرد رسالة تنبيه، يمكن استبدالها بتغيير النصوص داخل الصفحات
}

// تأثير تفاعل عند التمرير على العناصر (أثناء التمرير)
window.addEventListener("scroll", function() {
  const elements = document.querySelectorAll('.intro');
  elements.forEach(element => {
    const position = element.getBoundingClientRect().top;
    if (position < window.innerHeight - 100) {
      element.classList.add('fade-in');
    }
  });
});

// إضافة تأثير fade-in عند ظهور العناصر على الصفحة
document.addEventListener("DOMContentLoaded", function() {
  const elements = document.querySelectorAll('.intro');
  elements.forEach(element => {
    element.classList.add('fade-in');
  });
});function toggleLanguage() {
  alert("هذه الميزة ستتوفر لاحقًا");
}